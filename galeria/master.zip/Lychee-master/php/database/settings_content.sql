# Content of table lychee_settings
# Version 2.5
# ------------------------------------------------------------

INSERT INTO `?` (`key`, `value`)
VALUES
  ('version',''),
  ('username',''),
  ('password',''),
  ('thumbQuality','90'),
  ('checkForUpdates','1'),
  ('sortingPhotos','ORDER BY id DESC'),
  ('sortingAlbums','ORDER BY id DESC'),
  ('medium','1'),
  ('imagick','1'),
  ('dropboxKey',''),
  ('identifier',''),
  ('skipDuplicates','0'),
  ('plugins','');